from django.shortcuts import render
from django.template import RequestContext, loader, Template
from wikiApp.models import Users, Requests, Articles, Content
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts  import render_to_response,redirect
from django.template.context_processors import csrf
from django.template import Context
from django.views.decorators.csrf import csrf_exempt
from django.utils import timezone

# Create your views here.

@csrf_exempt
def mainPage(request):
	if request.GET:
		if request.GET.get("editPage"):
			#return HttpResponse("you want to edit")
			return render (request, "edit.html")

		if request.GET.get("deletePage"):
			#return HttpResponse("you want to delete")
			return render (request, "delete.html")

		if request.GET.get("createPage"):
			#return HttpResponse("you want to create")
			return render (request, "create.html")

	
	return render (request, "edit_home.html")

@csrf_exempt
def Create(request):
	context = {}
	if request.GET.get("submitForApproval"):
		default_user = Users.objects.filter(pk=2)
		#article_collection = Articles.objects.get(users=default_user.id)
		#heading = "hello world"
		heading = request.GET.get("heading")
		paragraph = request.GET.get("paragraph")
		new_article = Articles(users=default_user,title=heading,articleStatus='pending',date_published=timezone.now())
		new_article.save()

		#a = Articles.objects.
		#b = Content(heading=heading, paragraph=paragraph, articles=heading)
		#b.save()
		context = Context({"heading" : heading,
						   "paragraph" : paragraph,
							})
		return render (request, "article_submission.html",context)
		#return HttpResponse("THis works")
	return render (request, "edit.html")
	#return HttpResponse("THis does not work")

@csrf_exempt
def Edit(request):
	return render (request, "edit.html")
	

@csrf_exempt
def Delete(request):
	return render (request, "delete.html")

@csrf_exempt
def articleSubmission(request):
	return render (request, "article_submission.html")
