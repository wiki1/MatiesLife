from django.conf.urls import url

from . import views

urlpatterns = [
    url(r'^$', views.mainPage, name='mainPage'),
    url(r'^create/$', views.Create, name = 'Create'),
    url(r'^edit/$', views.Edit, name = 'Edit'),
    url(r'^delete/$', views.Delete, name = 'Delete'),
    url(r'^article_submission/$', views.articleSubmission, name = 'articleSubmission'),
]